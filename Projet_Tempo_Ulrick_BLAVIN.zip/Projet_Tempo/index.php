<!DOCTYPE html>
<html>
<head>

       <link rel="stylesheet" href="style.css" />
	  <link rel="shortcut icon" type="image/x-icon" href="images/microchip.ico" />
        <title>Temperature</title>
		<h1>CAPTEUR DE TEMPERATURE</h1>
</head>
<body>
 <div>
 <?php include ('grapheTempo.php'); ?>
	</div>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
setInterval(function(){
$("#content").load('BaseTempo.php #box1')
}, 1000);
});
</script>
<div id="content"></div>
</body>
<html>