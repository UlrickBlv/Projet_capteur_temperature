<?php
ini_set('display_errors', 'on'); 
// Établir une connexion à la base de données en utilisant PDO
try {
    $conn = new PDO("mysql:host=localhost;dbname=sensor_data", "root", "");
    // Définir le mode d'erreur pour PDO sur exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }

// Préparer et exécuter une requête pour récupérer les températures de la base de données
$stmt = $conn->prepare("SELECT * FROM SensorData ORDER BY DateN DESC LIMIT 20");
$stmt->execute();
$data = $stmt->fetchAll();
foreach($data as $row){
$temperatures[] = $row['tempo'];
$temps[] = $row['DateN'];

}

// Récupérer les résultats de la requête dans un tableau

?>
<!DOCTYPE html>
<html>
<head>
    <title>Graphique de températures</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>
</head>
<body>
    <canvas id="tempChart"></canvas>
    <script>
        var ctx = document.getElementById('tempChart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($temps) ?>,
                datasets: [{
                    label: 'Températures',
                    data: <?php echo json_encode($temperatures) ?>,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
<?php
header("refresh: 5");
?>
