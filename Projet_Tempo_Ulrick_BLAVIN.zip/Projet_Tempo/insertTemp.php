<?php
ini_set('display_errors', 'on'); 
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "sensor_data";
try{
$pdo = new PDO("mysql:host=$servername;dbname=sensor_data", $username, $password);
// set the PDO error mode to exception
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOEception $e){
	echo $e->getMessage();
	
}

$api_key_value = "tPmAT5Ab3j7F9";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
$api_key = $_GET["apiKeyValue"];
if($api_key == $api_key_value) {
	 $temperature = $_GET["tempo"];
	 $today = date("H:i:s");
	 $today2 = date("Y-m-d H:i:s"); 
     /*$arrayD[] = $dist;
	 $arrayT[] = $today;*/
		
	 
       $sql = "INSERT INTO `SensorData`(`tempo`, `DateN`) VALUES (:tempo,:DateN)";
  		$res = $pdo->prepare($sql);
  		$exec = $res->execute(array(":tempo"=>$temperature,":DateN"=>$today2));

  }
  else {
        echo "Wrong API Key provided.";
    }
    }
  else {
  	echo "No data posted with HTTP POST.";
  }