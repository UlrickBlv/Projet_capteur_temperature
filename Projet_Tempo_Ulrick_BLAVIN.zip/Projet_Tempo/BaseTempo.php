<html>
<head>
<?php
ini_set('display_errors', 'on'); 
?>
       <link rel="stylesheet" href="style.css" />

</head>
<div id="box1" >

<?php
$now = date('Y-m-d H:i:s');
echo "<p>$now</p>";

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "sensor_data";

try{
	
	 $db = new PDO("mysql:host=$servername;dbname=sensor_data", $username, $password);
}
catch(PDOEception $e){
	echo $e->getMessage();
	
}
$stmt = $db->prepare('SELECT * FROM SensorData ORDER BY DateN DESC LIMIT 0,10');
$stmt->execute();
$mes2 = $stmt->fetchAll();

$stmt4 = $db->prepare('SELECT Min(tempo) as donnees FROM SensorData');
$stmt4->execute();
$msg5 = $stmt4->fetch();

$stmt2 = $db->prepare('SELECT Max(tempo) as donnees FROM SensorData');
$stmt2->execute();
$msg3 = $stmt2->fetch();
//echo $msg3['donnees'];

$stmt3 = $db->prepare('SELECT AVG(tempo) as donnees FROM SensorData');
$stmt3->execute();
$msg4 = $stmt3->fetch();
 ?>
 <div id="tableau">
<table id="tableau-style">
            
             	<thead>
				<tr>
						<th colspan="4">DONNÉES</th>
				</tr>
				<tr>
						<th>DATE</th>
                        <th>VALEUR</th>
						
            	</tr>
				 </thead>
             <tbody>
			 <?php
			 foreach ($mes2 as $select) {
				 ?>
				 <tr>
				  <td><?= $select['DateN'];?></td>
				  <td><?= $select['tempo'];?></td><br>
				 </tr>
			<?php }?>			 
			  </tbody>
              </table>
			  
			  <table id="statistique">
				<tr>
				         <th>MIN</th>
						 <th>MOYENNE</th>
						<th>MAX</th>
						
						
				</tr>
				<tr>
						<td><div id="col_min"><?php echo $msg5['donnees']; ?></div></td>
						<td><div id="col_moyenne"><?php echo $msg4['donnees']; ?></div></td>
						<td><div id="col_max"><?php echo $msg3['donnees'] ?></div></td>
				
				</tr>
			  </table>
</div>

</div>
</html>